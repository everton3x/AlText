
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","altext()"],["c","AlTextMerge"],["c","AlTextParser"],["c","Exception"]];
